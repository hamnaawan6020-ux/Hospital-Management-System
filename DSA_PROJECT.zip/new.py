<think>
First, the error is: AttributeError: module 'PIL.Image' has no attribute 'ANTIALIAS'


## Identifying the error  
- The error "AttributeError: module 'PIL.Image' has no attribute 'ANTIALIAS'" indicates a compatibility issue.  
- This occurs because ANTIALIAS is deprecated in newer Pillow versions, replaced by Image.LANCZOS.
</think>```python
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
import pygame

# ================== STYLE ==================
STYLE = {
    "bg": "#f5f0eb",
    "card_bg": "#ffffff",
    "header_bg": "#6f4e37",
    "sidebar_bg": "#9b8ec1",
    "text_color": "#3d2b1f",
    "button_bg": "#6f4e37",
    "button_hover": "#9b8ec1",
    "font_header": ("Segoe Print", 20, "bold"),
    "font_card_header": ("Segoe Print", 16, "bold"),
    "font_text": ("Segoe UI", 12),
    "font_small": ("Segoe UI", 10)
}

# ================== DATABASE ==================
conn = sqlite3.connect("hospital.db")
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,age TEXT,disease TEXT)")
cursor.execute("CREATE TABLE IF NOT EXISTS doctors(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,specialization TEXT,contact TEXT)")
cursor.execute("CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient TEXT,doctor TEXT,date TEXT,time TEXT,problem TEXT)")
cursor.execute("CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY AUTOINCREMENT,patient TEXT,doctor TEXT,consultation REAL,medicine REAL,room REAL,total REAL)")
conn.commit()

# ================== SOUND ==================
pygame.mixer.init()
try:
    click_sound = pygame.mixer.Sound("click.mp3")
except:
    click_sound = None
def play_click_sound():
    if click_sound: click_sound.play()

# ================== PDF ==================
def generate_full_patient_report(patient_name):
    cursor.execute("SELECT * FROM patients WHERE name=?", (patient_name,))
    patient = cursor.fetchone()
    if not patient:
        messagebox.showerror("Error", f"No patient found with name {patient_name}")
        return

    cursor.execute("SELECT doctor, date, time, problem FROM appointments WHERE patient=?", (patient_name,))
    appointments = cursor.fetchall()

    cursor.execute("SELECT doctor, consultation, medicine, room, total FROM bills WHERE patient=?", (patient_name,))
    bills = cursor.fetchall()

    filename = f"{patient_name}_full_report.pdf"
    doc = SimpleDocTemplate(filename, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=60, bottomMargin=40)
    elements = []

    styles = getSampleStyleSheet()
    title_style = styles['Title']
    title_style.fontName = 'Helvetica-Bold'
    title_style.textColor = colors.HexColor('#6f4e37')
    subtitle_style = styles['Heading2']
    subtitle_style.fontName = 'Helvetica-Bold'
    subtitle_style.textColor = colors.HexColor('#9b8ec1')

    elements.append(Paragraph("🏥 Hospital Management System", title_style))
    elements.append(Paragraph(f"Full Report for {patient_name}", subtitle_style))
    elements.append(Spacer(1, 0.2*inch))

    # Patient
    elements.append(Paragraph("Patient Details", subtitle_style))
    pdata = [['ID', 'Name', 'Age', 'Disease'], [patient[0], patient[1], patient[2], patient[3]]]
    ptable = Table(pdata, colWidths=[0.5*inch, 2*inch, 1*inch, 2*inch])
    ptable.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#9b8ec1')),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('GRID',(0,0),(-1,-1),1,colors.HexColor('#6f4e37')),
        ('BACKGROUND',(0,1),(-1,-1), colors.HexColor('#f5f0eb'))
    ]))
    elements.append(ptable)
    elements.append(Spacer(1,0.2*inch))

    # Appointments
    elements.append(Paragraph("Appointments", subtitle_style))
    adata = [['Doctor', 'Date', 'Time', 'Problem']] + [list(a) for a in appointments]
    atable = Table(adata, colWidths=[2*inch, 1.5*inch, 1.5*inch, 2.5*inch])
    atable.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#9b8ec1')),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('GRID',(0,0),(-1,-1),1,colors.HexColor('#6f4e37')),
        ('BACKGROUND',(0,1),(-1,-1), colors.HexColor('#f5f0eb'))
    ]))
    elements.append(atable)
    elements.append(Spacer(1,0.2*inch))

    # Billing
    elements.append(Paragraph("Billing Details", subtitle_style))
    bdata = [['Doctor', 'Consultation', 'Medicine', 'Room', 'Total']] + [list(b) for b in bills]
    btable = Table(bdata, colWidths=[2*inch, 1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch])
    btable.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#9b8ec1')),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('GRID',(0,0),(-1,-1),1,colors.HexColor('#6f4e37')),
        ('BACKGROUND',(0,1),(-1,-1), colors.HexColor('#f5f0eb'))
    ]))
    elements.append(btable)
    elements.append(Spacer(1,0.3*inch))
    elements.append(Paragraph("Thank you for choosing our hospital! 💜", styles['Normal']))

    doc.build(elements)
    messagebox.showinfo("PDF Generated", f"Full patient report saved as {filename}")

# ================== LOGIN ==================
def check_login():
    play_click_sound()
    if user.get()=="DSA_PROJECT" and pwd.get()=="09871234":
        login.destroy()
        main.deiconify()
    else:
        err.config(text="Invalid login details")

login = tk.Tk()
login.title("Hospital Login")
login.state('zoomed')
login.configure(bg=STYLE["bg"])

# ===== Load Doodle Image =====
img = Image.open("hospital_doodle.jpg")
img = img.resize((login.winfo_screenwidth(), login.winfo_screenheight()), Image.Resampling.LANCZOS)
bg_img = ImageTk.PhotoImage(img)
canvas = tk.Canvas(login, width=login.winfo_screenwidth(), height=login.winfo_screenheight(), highlightthickness=0)
canvas.pack(fill="both", expand=True)
canvas.create_image(0, 0, image=bg_img, anchor="nw")

# ===== Login Card =====
card_frame = tk.Frame(canvas, bg=STYLE["card_bg"], padx=40, pady=40)
canvas.create_window(login.winfo_screenwidth()//2, login.winfo_screenheight()//2, window=card_frame)

tk.Label(card_frame, text="🏥 Hospital Login", font=("Segoe Print",28,"bold"), bg=STYLE["card_bg"], fg=STYLE["header_bg"]).pack(pady=15)
tk.Label(card_frame, text="Secure & Friendly Management System", font=("Segoe Print",12), bg=STYLE["card_bg"], fg=STYLE["sidebar_bg"]).pack(pady=5)

tk.Label(card_frame, text="Username", bg=STYLE["card_bg"], fg=STYLE["text_color"]).pack(anchor="w", pady=(15,0))
user = tk.Entry(card_frame, font=("Segoe UI",14), bd=2, relief="groove")
user.pack(fill="x", pady=8)

tk.Label(card_frame, text="Password", bg=STYLE["card_bg"], fg=STYLE["text_color"]).pack(anchor="w", pady=(15,0))
pwd = tk.Entry(card_frame, show="*", font=("Segoe UI",14), bd=2, relief="groove")
pwd.pack(fill="x", pady=8)

err = tk.Label(card_frame, text="", bg=STYLE["card_bg"], fg="red")
err.pack(pady=5)

def on_enter(e): e.widget['bg'] = STYLE["button_hover"]
def on_leave(e): e.widget['bg'] = STYLE["button_bg"]

login_btn = tk.Button(card_frame,text="Login", bg=STYLE["button_bg"], fg="white", font=("Segoe Print",14,"bold"), command=check_login)
login_btn.pack(fill="x", pady=20)
login_btn.bind("<Enter>", on_enter)
login_btn.bind("<Leave>", on_leave)

tk.Label(login, text="© 2026 Cute Hospital System 💜", bg=STYLE["bg"], fg=STYLE["header_bg"], font=("Segoe Print",10)).pack(side="bottom", pady=10)

# ================== MAIN WINDOW ==================
main = tk.Tk()
main.withdraw()
main.title("Hospital Management System")
main.geometry("1200x700")
main.configure(bg=STYLE["bg"])

header = tk.Frame(main, bg=STYLE["header_bg"], height=60)
header.pack(fill="x")
tk.Label(header,text="🏥 Hospital Management System", bg=STYLE["header_bg"], fg="white", font=STYLE["font_header"]).pack(pady=10)

sidebar = tk.Frame(main, bg=STYLE["sidebar_bg"], width=220)
sidebar.pack(side="left", fill="y")

content = tk.Frame(main, bg=STYLE["bg"])
content.pack(fill="both", expand=True)

def clear():
    for w in content.winfo_children(): w.destroy()

# ================== PATIENT UI ==================
def patient_ui():
    clear()
    f = tk.Frame(content, bg=STYLE["card_bg"], padx=20, pady=20)
    f.pack(pady=40)
    tk.Label(f,text="Patient Management", bg=STYLE["card_bg"], fg=STYLE["header_bg"], font=STYLE["font_card_header"]).grid(row=0,columnspan=2,pady=10)
    labels = ["Name","Age","Disease"]
    entries=[]
    for i,l in enumerate(labels):
        tk.Label(f,text=l,bg=STYLE["card_bg"],fg=STYLE["text_color"]).grid(row=i+1,column=0,sticky="w")
        e = tk.Entry(f); e.grid(row=i+1,column=1); entries.append(e)

    def save():
        play_click_sound()
        cursor.execute("INSERT INTO patients(name,age,disease) VALUES(?,?,?)",(entries[0].get(),entries[1].get(),entries[2].get()))
        conn.commit()
        view()
    tk.Button(f,text="Save", bg=STYLE["button_bg"], fg="white", command=save).grid(row=4,columnspan=2,pady=10)

    lb = tk.Listbox(f,width=60)
    lb.grid(row=5,columnspan=2)
    def view():
        lb.delete(0, tk.END)
        for r in cursor.execute("SELECT * FROM patients"): lb.insert(tk.END,r)
    view()

    tk.Label(f,text="Generate Full Patient Report:", bg=STYLE["card_bg"], fg=STYLE["header_bg"], font=STYLE["font_text"]).grid(row=6,column=0,pady=15)
    patient_name_entry = tk.Entry(f); patient_name_entry.grid(row=6,column=1)
    tk.Button(f,text="Generate PDF", bg=STYLE["button_hover"], fg="white",
              command=lambda:[play_click_sound(), generate_full_patient_report(patient_name_entry.get())]).grid(row=7,columnspan=2,pady=10)

# ================== DOCTOR UI ==================
def doctor_ui():
    clear()
    f = tk.Frame(content, bg=STYLE["card_bg"], padx=20, pady=20)
    f.pack(pady=40)
    tk.Label(f,text="Doctor Management", bg=STYLE["card_bg"], fg=STYLE["header_bg"], font=STYLE["font_card_header"]).grid(row=0,columnspan=2,pady=10)
    labels = ["Name","Specialization","Contact"]
    entries=[]
    for i,l in enumerate(labels):
        tk.Label(f,text=l,bg=STYLE["card_bg"],fg=STYLE["text_color"]).grid(row=i+1,column=0,sticky="w")
        e = tk.Entry(f); e.grid(row=i+1,column=1); entries.append(e)

    def save():
        play_click_sound()
        cursor.execute("INSERT INTO doctors(name,specialization,contact) VALUES(?,?,?)",(entries[0].get(),entries[1].get(),entries[2].get()))
        conn.commit()
        view()
    tk.Button(f,text="Save", bg=STYLE["button_bg"], fg="white", command=save).grid(row=4,columnspan=2,pady=10)

    lb = tk.Listbox(f,width=60)
    lb.grid(row=5,columnspan=2)
    def view():
        lb.delete(0, tk.END)
        for r in cursor.execute("SELECT * FROM doctors"): lb.insert(tk.END,r)
    view()

# ================== APPOINTMENT UI ==================
def appointment_ui():
    clear()
    f = tk.Frame(content, bg=STYLE["card_bg"], padx=20, pady=20)
    f.pack(pady=40)
    tk.Label(f,text="Appointment Management", bg=STYLE["card_bg"], fg=STYLE["header_bg"], font=STYLE["font_card_header"]).grid(row=0,columnspan=2,pady=10)
    labels = ["Patient","Doctor","Date","Time","Problem"]
    entries=[]
    for i,l in enumerate(labels):
        tk.Label(f,text=l,bg=STYLE["card_bg"],fg=STYLE["text_color"]).grid(row=i+1,column=0,sticky="w")
        e = tk.Entry(f); e.grid(row=i+1,column=1); entries.append(e)

    def save():
        play_click_sound()
        cursor.execute("INSERT INTO appointments(patient,doctor,date,time,problem) VALUES(?,?,?,?,?)",(entries[0].get(),entries[1].get(),entries[2].get(),entries[3].get(),entries[4].get()))
        conn.commit()
        view()
    tk.Button(f,text="Save", bg=STYLE["button_bg"], fg="white", command=save).grid(row=6,columnspan=2,pady=10)

    lb = tk.Listbox(f,width=60)
    lb.grid(row=7,columnspan=2)
    def view():
        lb.delete(0, tk.END)
        for r in cursor.execute("SELECT * FROM appointments"): lb.insert(tk.END,r)
    view()

# ================== BILLING UI ==================
def billing_ui():
    clear()
    f = tk.Frame(content, bg=STYLE["card_bg"], padx=20, pady=20)
    f.pack(pady=40)
    tk.Label(f,text="Billing Management", bg=STYLE["card_bg"], fg=STYLE["header_bg"], font=STYLE["font_card_header"]).grid(row=0,columnspan=2,pady=10)
    labels = ["Patient","Doctor","Consultation","Medicine","Room"]
    entries=[]
    for i,l in enumerate(labels):
        tk.Label(f,text=l,bg=STYLE["card_bg"],fg=STYLE["text_color"]).grid(row=i+1,column=0,sticky="w")
        e = tk.Entry(f); e.grid(row=i+1,column=1); entries.append(e)

    def save():
        play_click_sound()
        cons = float(entries[2].get() or 0)
        med = float(entries[3].get() or 0)
        room = float(entries[4].get() or 0)
        total = cons + med + room
        cursor.execute("INSERT INTO bills(patient,doctor,consultation,medicine,room,total) VALUES(?,?,?,?,?,?)",(entries[0].get(),entries[1].get(),cons,med,room,total))
        conn.commit()
        view()
    tk.Button(f,text="Save", bg=STYLE["button_bg"], fg="white", command=save).grid(row=6,columnspan=2,pady=10)

    lb = tk.Listbox(f,width=60)
    lb.grid(row=7,columnspan=2)
    def view():
        lb.delete(0, tk.END)
        for r in cursor.execute("SELECT * FROM bills"): lb.insert(tk.END,r)
    view()

# ================== SIDEBAR BUTTONS ==================
def create_sidebar_button(text, command):
    btn = tk.Button(sidebar, text=text, bg=STYLE["button_bg"], fg="white", width=20, font=STYLE["font_text"], command=lambda:[play_click_sound(), command()])
    btn.pack(pady=15)
    btn.bind("<Enter>", on_enter)
    btn.bind("<Leave>", on_leave)

create_sidebar_button("Patients", patient_ui)
create_sidebar_button("Doctors", doctor_ui)
create_sidebar_button("Appointments", appointment_ui)
create_sidebar_button("Billing", billing_ui)

login.mainloop()
main.mainloop()